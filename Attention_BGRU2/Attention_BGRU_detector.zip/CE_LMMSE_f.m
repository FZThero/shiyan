function h_LMMSE_f = CE_LMMSE_f(in,pilot)
    
    y=zeros(6*12,14);
    p=zeros(6*12,14);
    
    t_max = 6;
    trms = 3;
    nVar = prm.VarN;%db
    
    L=12*6;
    
    N_p = L;

     i=[1 5 10];
     j = 1:L;
     p(j,i)=pilot;
     y(j,i) = in(j,i);
            
      H_LS = y./p;
      H_LS = H_LS(:,i);
       for k=1:N_p 
            for l=1:N_p
                Rhh(k,l)=(1-exp((-1)*t_max*((1/trms)+1j*2*pi*(k-l)/N_p)))./(trms*(1-exp((-1)*t_max/trms))*((1/trms)+1j*2*pi*(k-l)/N_p)); 
            end 
        end 
        
        for mm = 1:3 
            Hlmmse(:,mm)=Rhh*inv(Rhh+(nVar)*eye(N_p))*H_LS(:,mm);
        end     
    
        H = zeros(L,14);
        H(:,i) = Hlmmse;
       i=[1 5 10];
      j=1:14;
     for k=1:L
         h_LMMSE_f(k,1:14)=interp1(i,H(k,i),j,'linear','extrap');
     end
    
end