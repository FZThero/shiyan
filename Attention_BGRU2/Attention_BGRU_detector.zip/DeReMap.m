function [out] = DeReMap_C(in)


    L = 72

        i=[1 5 10];
        j = 1:L;
        in(j,i) = 10;

        k=1;
            for p = 1:L
                for q = 1:14     
                    if in(p,q)~=10
                        y(k) = in(p,q);
                       %hn(k) = h(p,q);
                        k=k+1;
                    end
                end
            end
            
        out = reshape(y,[],1);
%        hn = reshape(hn,[],1);

 


end