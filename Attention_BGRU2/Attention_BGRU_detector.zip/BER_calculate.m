clear all
clear functions

SNR = 0:5:25;
N_SNR = length(SNR);
N_subframs =2000;%2��ʱ϶һ����֡
data_symbol=11;
pilot_symbol =3;
total_symbol=14;
carrier_num=72;
bit_num = data_symbol*carrier_num*2;

for t = 1:N_SNR
    prm.SNR_k = SNR(t);%ȡ��������
    prm.VarN = 10.^(0.1.*(-prm.SNR_k));%������������
    disp(SNR(t));
        for i=1:N_subframs%ȡ2����֡
             filename1 = ['.\Attention_BGRU_matric150kmh\','channelSNR',num2str(prm.SNR_k),'dB',num2str(i),'.txt'];
             h_suanfa1 = load(filename1,'ascii');
             h_suanfa2 = h_suanfa1(:,1:72)+h_suanfa1(:,73:144)*j; %(14,72)
             h_suanfa = h_suanfa2.';
%         
             filename2= ['.\H_test_labelnew72carrier150kmh\','channelSNR',num2str(prm.SNR_k),'dB',num2str(i),'.txt'];
             h_BEM_label1 = load(filename2,'ascii');
             h_BEM_label = h_BEM_label1(:,1:72)+h_BEM_label1(:,73:144)*j;
             h_BEM_label = h_BEM_label.';
             

             
             filename4 = ['.\R_test_data_new72carrier150kmh\','channelSNR',num2str(prm.SNR_k),'dB',num2str(i),'.txt'];
             receive_data1 = load(filename4,'ascii');
             receive_data2 = receive_data1(:,1:72)+receive_data1(:,73:144)*j;  %(14,72)
             receive_data = receive_data2.';
             
              filename3 = ['.\orginsymboldatanew72carrier150kmh\','dataSNR',num2str(prm.SNR_k),'dB',num2str(i),'.txt'];
             origin_data1 = load(filename3,'ascii');
             origin_data = origin_data1(:,1)+origin_data1(:,2)*j;  %(1584,1)
             



        r2_suanfa_l = equlaizer_F(receive_data,h_suanfa);
        r3_suanfa_l = DeReMap(r2_suanfa_l);  
        r4_suanfa_l = Demodulator(r3_suanfa_l);%(72*11*2,1)
        
        

        N_errors0(i)  = sum( r4_suanfa_l~=origin_data);

        end

        BER_suanfa(t) =sum(N_errors0)./(N_subframs*bit_num);

end
SNRind=1:N_SNR;
figure('name','BER'),
semilogy(SNR(SNRind), BER_suanfa(SNRind),'*-b','MarkerSize',10);
hold on,
legend('Attention_BGRU');
grid on,
figure_FontSize=12;
set(get(gca,'XLabel'),'FontSize',figure_FontSize,'Vertical','top');
set(get(gca,'YLabel'),'FontSize',figure_FontSize,'Vertical','middle');
set(findobj('FontSize',12),'FontSize',figure_FontSize);
set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',1.5);
xlabel('SNR /dB');
ylabel('BER');
