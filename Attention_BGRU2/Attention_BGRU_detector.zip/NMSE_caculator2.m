function [ML] = NMSE_caculator2(h_estimation,h_p,prm)
    cpLenR = prm.cpLenR;%72
    N = prm.N;%600
    
%     for k = 1:14%ȥ����ʵ�ŵ���Ӧ�е�cp����
%         
%         h( ((k-1)*N +1) : k*N , : ) = hImp((  cpLenR+(k-1)*(cpLenR+N)  ):( ( cpLenR+(k-1)*(cpLenR+N) )  + N -1 ),:);
%         
%     end
        
   % h = reshape(h,length(h_estimation),1);

    A=sum(sum((abs(h_estimation-h_p)).^2));
%     B=sum(sum((abs(h_p)).^2));
    B=14*72
%     ML=(A./B);
ML=(A./B);
end