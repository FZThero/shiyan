function [out_f] = equlaizer_F(in,h_n)

        out_f = in./h_n;

end