function h_LS_f = CE_LS_f(in,pilot)
    
    y=zeros(6*12,14);
    p=zeros(6*12,14);
    
    L=12*prm.Nrb;
    
     i=[1 5 10];
     j = 1:L;
     p(j,i)=pilot;
     y(j,i) = in(j,i);
            
     H = y./p;

      i=[1 5 10];
      j=1:14;
     for k=1:L
         h_LS_f(k,1:14)=interp1(i,H(k,i),j,'linear','extrap');
     end
    
end